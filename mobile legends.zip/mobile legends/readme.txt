Membuat member menjadi default

edit tag body (baris 14) di login.html menjadi 

<body onload="member();">
